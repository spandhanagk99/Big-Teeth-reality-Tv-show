<?php 
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'database_project');

	// initialize variables
	$name = "";
	$address = "";
	$id = 0;
	$update = false;

	if (isset($_POST['save'])) {
		$eventID = $_POST['eventID'];
		$contestantID = $_POST['contestantID'];
		$team_name = $_POST['team_name'];
		$task = $_POST['task'];
		$result = $_POST['result'];
		$points = $_POST['points'];
		$prize = $_POST['prize'];
		

		mysqli_query($db, "INSERT INTO event_contestant_participated (eventID,contestantID,team_name, task,result,points,prize) VALUES ('$eventID', '$contestantID','$team_name','$task','$result','$points','$prize')"); 
		$_SESSION['message'] = "event saved"; 
		header('location: event_information.php');
	}
	
if (isset($_POST['update'])) {

	$eventID = $_POST['eventID'];
		$contestantID = $_POST['contestantID'];
		$team_name = $_POST['team_name'];
		$task = $_POST['task'];
		$result = $_POST['result'];
		$points = $_POST['points'];
		$prize = $_POST['prize'];

	mysqli_query($db, "UPDATE event_contestant_participated SET eventID='$eventID', contestantID='$contestantID',team_name='$team_name',task='$task',result='$result',points='$points',prize='$prize' WHERE eventID=$eventID");
	$_SESSION['message'] = "event updated!"; 
	header('location: event_information.php');
}
if (isset($_GET['del'])) {
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM event_contestant_participated WHERE eventID=$eventID");
	$_SESSION['message'] = "event deleted!"; 
	header('location: event_information.php');
}
?>