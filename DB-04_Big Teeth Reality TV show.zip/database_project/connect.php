<?php
$contestantID= $_POST['contestantID'];
	$First= $_POST['First'];
	$Last = $_POST['Last'];
    $streetaddress = $_POST['streetaddress'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $postalcode = $_POST['postalcode'];
    $country = $_POST['country'];
    $bdate = $_POST['bdate'];
	$gender = $_POST['gender'];
    $daytimephone = $_POST['daytimephone'];
    $nighttimephone = $_POST['nighttimephone'];
	$email = $_POST['email'];
    $essay = $_POST['essay'];
	$filename = $_POST['filename'];
	$video = $_POST['video'];

	// Database connection
	$conn = new mysqli('localhost','root','','database_project');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into contestant_details(contestantID,First, Last,streetaddress, city,state,postalcode,country,bdate, gender, daytimephone,nighttimephone, email, essay,filename, video) values(?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?,?, ?, ?, ?)");
		$stmt->bind_param("isssssisssiissss", $contestantID,$First, $Last,$streetaddress, $city,$state,$postalcode,$country,$bdate, $gender, $daytimephone,$nighttimephone, $email, $essay,$filename, $video);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registration successfully...";
		if(isset($_POST["submit1"]))
{
  header('Location: applicationform.php');
}
		$stmt->close();
		$conn->close();
	}
?>