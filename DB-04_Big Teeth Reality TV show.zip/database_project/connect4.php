<?php
$contestantID = $_POST['contestantID'];
	$eventID = $_POST['eventID'];
    $episodeID = $_POST['episodeID'];
	$title = $_POST['title'];
    $event_description = $_POST['event_description'];
    $estimated_time = $_POST['estimated_time'];
	$estimated_danger= $_POST['estimated_danger'];
	$actionID = $_POST['actionID'];
    $sequence = $_POST['sequence'];
    $actiondescription = $_POST['actiondescription'];
    $cameras = $_POST['cameras'];
    $estimatedtime = $_POST['estimatedtime'];
    $directorID = $_POST['directorID'];
    $producerID = $_POST['producerID'];
    $director_rating = $_POST['director_rating'];
    $producer_rating = $_POST['producer_rating'];
    $rid=$_POST['rid'];


	// Database connection
	$conn = new mysqli('localhost','root','','database_project');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt1 = $conn->prepare("insert events(eventID, episodeID,date,title,event_description,estimated_time,estimated_danger) values(?, ?, ?, ?,?,?,?)");
		$stmt1->bind_param("iisssss", $eventID, $episodeID,$date,$title,$event_description,$estimated_time,$estimated_danger);
		$execval1 = $stmt1->execute();

        $stmt2 = $conn->prepare("insert actions(actionID, episodeID,sequence,actiondescription,cameras,estimatedtime) values(?, ?, ?, ?,?,?)");
		$stmt2->bind_param("iissis", $actionID, $episodeID,$sequence,$actiondescription,$cameras,$estimatedtime);
		$execval2 = $stmt2->execute();

        $stmt3 = $conn->prepare("insert rating(rid,directorID,producerID,contestantID,eventID,director_rating,producer_rating) values(?,?, ?, ?,?, ?,?)");
		$stmt3->bind_param("iiiiiii",$rid, $directorID,$producerID,$contestantID,$eventID,$director_rating,$producer_rating);
		$execval3 = $stmt3->execute();
		echo $execval1;
        echo $execval2;
        echo $execval3;
		echo "Registration successfully...";
		if(isset($_POST["submit1"]))
{
  header('Location: event_details.html');
}
		$stmt1->close();
        $stmt2->close();
        $stmt3->close();
		$conn->close();
	}
?>