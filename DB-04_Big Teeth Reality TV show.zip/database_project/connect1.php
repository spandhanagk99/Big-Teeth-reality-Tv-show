<?php
	$jobid = $_POST['jobid'];
	$contestantID = $_POST['contestantID'];
	$companyname = $_POST['companyname'];
	$description = $_POST['description'];
	$startdate = $_POST['startdate'];
	$enddate = $_POST['enddate'];

	// Database connection
	$conn = new mysqli('localhost','root','','database_project');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into previous_jobs(jobid, contestantID, companyname, description, startdate, enddate) values(?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("iissss", $jobid, $contestantID, $companyname, $description, $startdate, $enddate);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registration successfully...";
		if(isset($_POST["submit1"]))
{
  header('Location: previous_jobs.php');
}
		$stmt->close();
		$conn->close();
	}
?>