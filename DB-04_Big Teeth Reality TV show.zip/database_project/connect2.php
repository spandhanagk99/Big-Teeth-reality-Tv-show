<?php
	$medical_record_id = $_POST['medical_record_id'];
	$contestantID = $_POST['contestantID'];
	$medications = $_POST['medications'];
	$reasons = $_POST['reasons'];


	// Database connection
	$conn = new mysqli('localhost','root','','database_project');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into medical_records(medical_record_id, contestantID,medications,reasons) values(?, ?, ?, ?)");
		$stmt->bind_param("iiss", $medical_record_id, $contestantID, $medications, $reasons);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registration successfully...";
		if(isset($_POST["submit1"]))
{
  header('Location: medication form.html');
}
		$stmt->close();
		$conn->close();
	}
?>