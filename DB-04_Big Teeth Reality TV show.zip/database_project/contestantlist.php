
<!DOCTYPE html>
<html>
<head>
<title>Big Teeth Reality TV SHOW</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.tooltip {
               display: inline;
               position: relative;
               text-decoration: none;
               top: -10px;
               left: 8px;
               text-align: center;
           }
   
               .tooltip:hover:after {
                   background: #333;
                   background: rgba(0,0,0,.8);
                   border-radius: 7px;
                   top: -5px;
                   color: #fff;
                   content: attr(alt);
                   left: 300px;
                   padding: 5px 15px;
                   position: absolute;
                   z-index: 98;
                   width: 400px;
               }
   
               .tooltip:hover:before {
                   border: solid;
                   border-color: transparent black;
                   border-width: 6px 6px 6px 0;
                   bottom: 100px;
                   content: "";
                   left: 295px;
                   position: absolute;
                   z-index: 99;
                   top: 4px;
               }
               
           .topnav {
 background-color: #333;
 overflow: hidden;
}
.login {
           position: absolute;
           top: 52%;
           left: 10%;
           margin: -150px 0 0 -100px;
           width: 650px;
           height: 400px;
       }
       .login h1 {
               color: #333;
               text-shadow: 0 0 10px rgba(0,0,0,0.3);
               letter-spacing: 7px;
               text-align: center;
           } 
           input {
           width: 100%;
           margin-bottom: 5px;
           background: #fff;
           border: none;
           outline: none;
           padding: 5px;
           font-size: 20px;
           color: black;
           text-shadow: 1px 1px 1px rgba(0,0,0,0.3);
           border: 1px solid rgba(0,0,0,0.3);
           border-radius: 6px;
           box-shadow: inset 0 -5px 45px rgba(100,100,100,0.2), 0 1px 1px rgba(255,255,255,0.2);
           -webkit-transition: box-shadow .5s ease;
           -moz-transition: box-shadow .5s ease;
           -o-transition: box-shadow .5s ease;
           -ms-transition: box-shadow .5s ease;
           transition: box-shadow .5s ease;
       }

           input:focus {
               box-shadow: inset 0 -5px 45px rgba(100,100,100,0.4), 0 1px 1px rgba(255,255,255,0.2);
           }  
           * {
 box-sizing: border-box;
}

.row {
 display: flex;
}

/* Create two equal columns that sits next to each other */
.column {
 flex: 50%;
 padding: 10px;
 height: 300px; /* Should be removed. Only for demonstration */
}

/* Style the links inside the navigation bar */
.topnav a {
 float: left;
 color: #f2f2f2;
 text-align: center;
 padding: 14px 16px;
 text-decoration: none;
 font-size: 17px;
}
button {
background-color: lightblue;
color: black;
font-size: 25px;
}

/* Change the color of links on hover */
.topnav a:hover {
 background-color: #ddd;
 color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
 background-color: #04AA6D;
 color: white;
}
          
       

      html, body {
      min-height: 100%;
      }
      body, div, form, input, label { 
      padding: 0;
      margin: 0;
      outline: none;
      font-family: Roboto, Arial, sans-serif;
      font-size: 13px;
      color: #666;
      line-height: 22px;
      }
      legend { 
      color: #fff;
      background-color: #8ebf42;
      padding: 3px 5px;
      font-size: 20px;
      font-weight: 600;
      }
      h1 {
      position: absolute;
      margin: 0;
      font-size: 36px;
      color: #fff;
      z-index: 2;
      }
      .testbox {
      display: flex;
      justify-content: center;
      align-items: center;
      height: inherit;
      padding: 20px;
      }
      form {
      width: 100%;
      padding: 20px;
      border-radius: 6px;
      background: #fff;
      box-shadow: 0 0 20px 0  #8ebf42; 
      }
      .banner {
      position: relative;
      height: 320px;
      background-image: url("8.jpg");  
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: center;
      }
      .banner::after {
      content: "";
      background-color: rgba(0, 0, 0, 0.6); 
      position: absolute;
      width: 100%;
      height: 100%;
      }
      input {
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 3px;
      }
      input[type=text] {
  width: 75%;
  padding: 1px 10px;
  margin: 8px 0;
  box-sizing: border-box;
}
    
      input[type="date"] {
      padding: 4px 5px;
      }
      .item:hover p, .item:hover i, .question:hover p, .question label:hover, input:hover::placeholder {
      color:#8ebf42;
      }
      .item input:hover {
      border: 1px solid transparent;
      box-shadow: 0 0 6px 0 #8ebf42;
      color:#8ebf42;
      }
      .item {
      position: relative;
      margin: 10px 0;
      }
      .item span {
      color: red;
      }
      input[type="date"]::-webkit-inner-spin-button {
      display: none;
      }
      .item i, input[type="date"]::-webkit-calendar-picker-indicator {
      position: absolute;
      font-size: 20px;
      color: #8ebf42;
      }
      .item i {
      right: 2%;
      top: 30px;
      z-index: 1;
      }
      [type="date"]::-webkit-calendar-picker-indicator {
      right: 1%;
      z-index: 2;
      opacity: 0;
      cursor: pointer;
      }
      .question span {
      margin-left: 30px;
      }
      .btn-block {
      margin-top: 10px;
      text-align: center;
      }
     
      button {
      width: 150px;
      padding: 10px;
      border: none;
      border-radius: 5px; 
      background: #8ebf42;
      font-size: 16px;
      color: #fff;
      cursor: pointer;
      }
      button:hover {
      background: #82b534;
      }
      input[type="text"]
{
    font-size:24px;
}
</style>
</head>
<body style="background-color:lightgray">
<div class="topnav">
      
      <a href="#" class="w3-bar-item w3-button w3-padding-large w3-black">
        <i class="fa fa-home w3-xxlarge"></i>
        <p>HOME</p>
      </a>
      <a href="#about" class="w3-bar-item w3-button w3-padding-large w3-hover-black">
        <i class="fa fa-user w3-xxlarge"></i>
        <p>ABOUT</p>
      </a>
      <a href="Application page.html#id_first" class="w3-bar-item w3-button w3-padding-large w3-hover-black">
        <i class="fa fa-file w3-xxlarge"></i>
        <p>APPLICATIONS</p>
      </a>
      <a href="Employee page.html#empid_first" class="w3-bar-item w3-button w3-padding-large w3-hover-black">
        <i class="fa fa-user w3-xxlarge"></i>
        <p>Employee Page</p>
      </a>
      <a href="voting poll.html#vid_first" class="w3-bar-item w3-button w3-padding-large w3-hover-black">
        <i class="fa fa-eye w3-xxlarge"></i>
        <p>Voting Poll</p>
      </a>
      <a href="contact" class="w3-bar-item w3-button w3-padding-large w3-hover-black">
        <i class="fa fa-envelope w3-xxlarge"></i>
        <p>CONTACT</p>
      </a>
    </div>
</div>
    <div class="js-tabs">
      <div id="empid_first" class="js-tabcontent">


        <div class="js-tabs">
         
        <div class="js-tabs">
      <div id="eid_firsty" class="js-tabcontent">
        <div class="js-tabs">
    <div class="testbox">

<div class="container">
    <div class="row">
      <div class="col-sm-8">
       <?php echo $deleteMsg??''; ?>
       <div class="table-responsive">
         <table class="table table-bordered">
         <fieldset style="width:800px">
        <legend>List of Contestants</legend>
          <thead><tr><th>contestantID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>streetaddress</th>
            <th>city</th>
            <th>state</th>
            <th>postalcode</th>
            <th>country</th>
            


       </thead>
       <tbody>
     <?php
         include("developers.php");
         if(is_array($fetchData)){      
         $sn=1;
         foreach($fetchData as $data){
       ?>
         <tr>
         <td><?php echo $sn; ?></td>
         <td><?php echo $data['First']??''; ?></td>
         <td><?php echo $data['Last']??''; ?></td>
         <td><?php echo $data['streetaddress']??''; ?></td>
         <td><?php echo $data['city']??''; ?></td>
         <td><?php echo $data['state']??''; ?></td>
         <td><?php echo $data['postalcode']??''; ?></td>
         <td><?php echo $data['country']??''; ?></td>
         
        </tr>
        <?php
         $sn++;}}else{ ?>
         <tr>
           <td colspan="8">
       <?php echo $fetchData; ?>
     </td>
       <tr>
       <?php
       }?>
       </tbody>
        </table>
        </fieldset>
      </div>
   </div>
   </div>
   </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
     
</body>
</html>
