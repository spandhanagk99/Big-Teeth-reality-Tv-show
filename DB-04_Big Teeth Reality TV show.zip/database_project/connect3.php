<?php
$contestantID = $_POST['contestantID'];
	$crimeID = $_POST['crimeID'];
    $date = $_POST['date'];
	$crime_record_description = $_POST['crime_record_description'];
    $outcome = $_POST['outcome'];
    $educationID = $_POST['educationID'];
	$school = $_POST['school'];
	$contact = $_POST['contact'];
    $degree = $_POST['degree'];
    $comments = $_POST['comments'];
    $employerID = $_POST['employerID'];
    $employer = $_POST['employer'];
    $phone = $_POST['phone'];
    $employercomments = $_POST['employercomments'];


	// Database connection
	$conn = new mysqli('localhost','root','','database_project');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt1 = $conn->prepare("insert crimerecord(crimeID, contestantID,date,crime_record_description,outcome) values(?, ?, ?, ?,?)");
		$stmt1->bind_param("iisss", $crimeID, $contestantID,$date,$crime_record_description,$outcome);
		$execval1 = $stmt1->execute();

        $stmt2 = $conn->prepare("insert education(educationID, contestantID,school,contact,degree,comments) values(?, ?, ?, ?,?,?)");
		$stmt2->bind_param("iisiss", $educationID, $contestantID,$school,$contact,$degree,$comments);
		$execval2 = $stmt2->execute();

        $stmt3 = $conn->prepare("insert employer(employerID,contestantID,employer,phone,employercomments) values(?, ?, ?, ?,?)");
		$stmt3->bind_param("iisis", $employerID, $contestantID,$employer,$phone,$employercomments);
		$execval3 = $stmt3->execute();
		echo $execval1;
        echo $execval2;
        echo $execval3;
		echo "Registration successfully...";
		if(isset($_POST["submit1"]))
{
  header('Location: medication form.html');
}
		$stmt1->close();
        $stmt2->close();
        $stmt3->close();
		$conn->close();
	}
?>